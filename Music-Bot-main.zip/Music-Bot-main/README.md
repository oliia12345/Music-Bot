<div align="center">
  
  
  <img src="musicbot.png" />

  <h2 align="center">Music Bot</h2>

 Discord music bot with buttons. Play a best quality music.

</div>


# Youtube Tutorial
https://www.youtube.com/watch?v=vdmME5pX_ho

![play](https://media.discordapp.net/attachments/885540251043495966/886869092781404201/unknown.png)


![help](https://media.discordapp.net/attachments/885540251043495966/886869220636385330/unknown.png)


# Setup
- Click **Star** in this project
- Add TOKEN in `.env` file
- Fill all the things in `config.json`
- Add Youtube API Key in `config.js`

**Your Bot is ready!**


# Replit Users : 

[Click Here](https://repl.it/github/diwasatreya/Music-Bot) 


# Contact
- Twitter: https://twitter.com/DiwasAtreya
